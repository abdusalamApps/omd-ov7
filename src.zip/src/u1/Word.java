package u1;

public interface Word {

    long value();
}
