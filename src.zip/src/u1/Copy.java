package u1;

public class Copy {
    public Copy(Word word) {

    }
}
