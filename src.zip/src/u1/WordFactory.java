package u1;

public class WordFactory {
    public static Word makeWord(String valueString) {
        long value = Long.parseLong(valueString);
        if (value < 100) {
            return new LongWord(value);
        } else if (value >= 100) {
            return new VeryLongWord(value);
        }
        return null;

    }
}
