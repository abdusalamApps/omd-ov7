package u1;

import java.util.ArrayList;

public class Factorial extends Program {

    public Factorial() {
        Address n = new Address(0),
                fac = new Address(1);
        add(new Copy(WordFactory.makeWord("90"), n));
    }
}
