package u2;

public class Circle extends Shape {

    public Circle() {
    }

    @Override
    public void move(int x, int y) {

    }

    @Override
    public void draw() {

    }

    @Override
    public void edit() {

    }
}
