package u2;

public abstract class Shape {

    public abstract void move(int x, int y);
    public abstract void draw();
    public abstract void edit();


    public static class Factory {
        public static Shape create(String type) {
            if (type.equalsIgnoreCase("Circle")) {
                return new Circle();
            } else if (type.equalsIgnoreCase("Square")) {
                return new Square();
            }
            throw new IllegalArgumentException("Unknown Shape Class");
        }
    }

}
