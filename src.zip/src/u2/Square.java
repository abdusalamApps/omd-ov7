package u2;

public class Square extends Shape {

    public Square() {
    }

    @Override
    public void move(int x, int y) {

    }

    @Override
    public void draw() {

    }

    @Override
    public void edit() {

    }
}
