package u2;

public class DrawingEditor {

    public Shape create(String shapeType) {
        return Shape.Factory.create(shapeType);
    }

}
